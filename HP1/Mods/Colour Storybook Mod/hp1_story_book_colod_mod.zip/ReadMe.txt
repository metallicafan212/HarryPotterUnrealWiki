Story book color mod for Harry Potter and the Sorcerers Stone.

En:
Unzip the contents of the archive into the folder with the game.

Ru:
Распакуйте содержимое архива в папку с игрой.

Mod by casperpro