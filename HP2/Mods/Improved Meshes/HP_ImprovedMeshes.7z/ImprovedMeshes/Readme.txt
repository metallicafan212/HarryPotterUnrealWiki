============Omega's Improved Harry Models (And some goodies!)============

	This contains all of the variations of Harry's model that I've made plus 
the improved standard one. A lot of hard work went into fixing the rigging
and giving this 12 year old boy an ass. 

	Unfortunately, there's no way to make it look "perfect" without a 
humongous amount of animation and bone set improvements, since the devs 
regularly broke Harry's pelvis for the climbing anims.

	In this pack, I will provide both source textures and models, as well
as pre-imported versions that you can use.

	If you want to use this to make new costumes and the like, go hog wild.
And be sure to ping me with whatever you create on the discord (I like seeing
people make stuff c:)

	The source assets are under the folder named "Src".
Don't copy them into your game lmao.
==============MODEL INFO===============
skHarryImpMesh - The standard mesh
	Note that material slot 1 on both of the cloaked models requires that you 
set Two Sided on the texture. Of note is that the shoe UVs are designed to 
be a flat projection, you can texture any part of the shoe. It was a challenge
to get the shoes to fit inside of the texture slot, but it was worth it.

skHarryBoots - A mesh for tucked boots
	No changed UVs, just his pants have been altered to look as if they tuck
into some boots. Make sure to set the cloak two sided.

skHarryCloakless - Cloakless Harry
	Mildly cursed, and it really reveals the animation oddities. No need for
two sided here.

skHarryCloaklessSW - Cloakless with small wrists
	This one's designed for an outfit such as T-shirts and the like, with essentially 
a tighter fit around his torso. It doesn't have any special UV differences between the
models (The new wrist verts are part of his arm UVs as you'd expect).

==============MODEL SETUP==============
	There's a bit of setup to do when you import the model, or import any model for Harry.
Animations:
	Under the Animation Tab, set the DefaultAnimation to "skHarryAnimsPatch" (You may type it in)
Under "AnimationLinks", add one and set the new link to "skHarryAnims". It will not show up in the
UI, but the model is now linked to both sets of animations for use ingame. Make sure to hit the 
Link button when you're done.

	The trick here is that I've only replaced certain animations from Harry's default set that had 
horrendous clipping. Spongify is gonna get reanimated later, I'm not happy fully with the current 
one I made but it's far better than how much it was clipping before.

	Now the mesh is ready to animate. However, you still need to give it weapon information.
Under "Weapon", set the Roll of the WeaponAdjRotation to "2560". Next, set the WeaponBone
to "RightHand". Congrats, you're done!

